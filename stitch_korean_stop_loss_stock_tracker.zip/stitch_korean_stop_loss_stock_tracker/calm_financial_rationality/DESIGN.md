---
name: Calm Financial Rationality
colors:
  surface: '#f7f9ff'
  surface-dim: '#d7dadf'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f9'
  surface-container: '#ebeef3'
  surface-container-high: '#e5e8ee'
  surface-container-highest: '#e0e3e8'
  on-surface: '#181c20'
  on-surface-variant: '#44474d'
  inverse-surface: '#2d3135'
  inverse-on-surface: '#eef1f6'
  outline: '#74777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#4a5f7f'
  primary: '#001229'
  on-primary: '#ffffff'
  primary-container: '#0f2744'
  on-primary-container: '#798fb1'
  inverse-primary: '#b2c8ed'
  secondary: '#a63b00'
  on-secondary: '#ffffff'
  secondary-container: '#fc671e'
  on-secondary-container: '#561b00'
  tertiary: '#0b1218'
  on-tertiary: '#ffffff'
  tertiary-container: '#20272d'
  on-tertiary-container: '#878e96'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#b2c8ed'
  on-primary-fixed: '#021c39'
  on-primary-fixed-variant: '#324866'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb598'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#7f2b00'
  tertiary-fixed: '#dce3ec'
  tertiary-fixed-dim: '#c0c7cf'
  on-tertiary-fixed: '#151c22'
  on-tertiary-fixed-variant: '#41484e'
  background: '#f7f9ff'
  on-background: '#181c20'
  surface-variant: '#e0e3e8'
typography:
  headline-lg:
    fontFamily: Noto Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Noto Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Noto Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Noto Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Noto Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Noto Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-numeric-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
  label-numeric-md:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 20px
  label-numeric-sm:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  label-meta:
    fontFamily: Noto Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies disciplined financial rationality, clinical clarity, and emotional calmness for retail equity investors confronting high-stress market decisions. When managing stop-loss scenarios, panic and cognitive bias are the primary failure points. The visual style counters this with structural restraint: clean Scandinavian minimalism fused with Korean typographical precision and utilitarian clarity.

Every screen prioritizes objective numerical truth over emotional feedback. The design eliminates decorative charts, aggressive glowing gradients, and gamified animations. Instead, the interface adopts a calm, high-density editorial structure that feels akin to an analytical institutional ledger—accessible, uncompromisingly clear, and anchored by dependable hierarchy.

Key experiential pillars:
- **Calm Authority**: Deep navy stabilizes the viewport; content sits atop an expansive white canvas.
- **Critical Contextual Awareness**: In the Korean exchange (KRX), red signifies positive upward movement and blue indicates downward drops. Therefore, standard Western semantic alerting (red = stop/danger) fails entirely. This system introduces high-visibility safety amber/orange as the critical intervention hue for loss limits and triggers, ensuring zero cognitive interference with directional market data.
- **Tactile Legibility**: Form obeys data rigor—tabular numerals, defined borders, consistent micro-spacers, and predictable interactive states.

## Colors

The color palette establishes an uncompromising analytical environment built on crisp pure whites, clinical architectural grays, an authoritative deep navy, and a distinct stop-loss alert orange.

### Surface and Canvas Architecture
- **Pure White Canvas (`#FFFFFF`)**: The root surface for maximum contrast, tabular readability, and ambient brightness.
- **Surface Muted (`#F8F9FA`)**: Container backgrounds, read-only field fills, and neutral table row alternating tints.
- **Surface Border Subtle (`#E9ECEF`)**: Primary divider and boundary stroke color across cards, headers, and list groups.
- **Surface Border Strong (`#ADB5BD`)**: Input field borders, inactive segment dividers, and secondary component contours.

### Core Semantic Roles
- **Primary Navy (`#0F2744`)**: Anchors critical user commitments—confirming risk triggers, system activation buttons, primary navigational markers, and high-level portfolio totals. It conveys institutional-grade execution.
- **Stop-Loss Attention Orange (`#E8590C`)**: The operational warning color for breach notifications, stop-loss threshold triggers, critical target updates, and destructive liquidation confirmations. Red is strictly banned for warnings, preserving clear mental separation from KRX 상승 (gain) indicators.
- **Text Primary (`#212529`)**: Used for all stock names, core values, monetary outputs, and headline statements.
- **Text Secondary (`#495057`)**: Used for labels, stock ticker codes, timestamp markers, and field helper text.
- **Text Muted (`#868E96`)**: Placeholder states and non-actionable sub-captions.

## Typography

The typographic hierarchy prioritizes bilateral clarity: idiomatic Korean hangul readability paired with precision numeric evaluation.

### Font Role Allocation
- **Primary Interface Font (`Noto Sans`)**: Handles all UI copy, navigation links, stock entity names (e.g., 삼성전자, SK하이닉스), and contextual advisory prose. Set with slightly tight letter tracking (`-0.02em`) optimized for standard Korean layout conventions.
- **Monospaced Data Font (`JetBrains Mono`)**: Mandated for all stock ticker symbols (e.g., `005930`), execution prices, target loss percentages, trade quantities, and timestamp logs. Enforces fixed column alignments across tabular layouts, eliminating visual jitter during real-time value changes.

### Typographic Discipline
1. **Zero Text Decoration**: Never underline numbers or data metrics.
2. **Tabular Numerals**: In contexts where primary UI text intersects numeric indicators, enable OpenType tabular figures (`font-variant-numeric: tabular-nums`).
3. **Weight Restraint**: Strictly limited to Regular (400) for prose and documentation, SemiBold (600) for structural headlines, and Medium (500) for mono figures. Bold (700) is reserved exclusively for major screen-level aggregated portfolio summaries.

## Layout & Spacing

The layout is grounded in a disciplined 8pt grid system configured to display dense financial data without visual suffocation. Whitespace is active rather than decorative, creating clear spatial buckets that separate assets, risk boundaries, and rule sets.

### Grid & Breakpoints
- **Mobile (`< 768px`)**: Single-column layout. Margin is fixed to `1rem` (16px) with an edge-to-edge content container. Lists and critical metrics stack vertically; actions remain persistently accessible along bottom sheets or pinned footers.
- **Tablet (`768px - 1023px`)**: 6-column fluid structure. Gutters scale to `1.25rem`. Two-column asymmetric cards display selected stock telemetry adjacent to current trigger thresholds.
- **Desktop (`≥ 1024px`)**: 12-column fixed system with a maximum inner container constraint of `1160px`. Gutters scale to `1.5rem`, while outer margins relax to `3rem`. Three primary zones operate in concert: Left-hand watchlist overview (4 columns), central operational calculation matrix (5 columns), and right-hand execution ledger (3 columns).

### Spatial Hierarchy
- **Card-level internals**: Always `space-md` (16px) for compact listings; scale to `space-lg` (24px) for execution confirmation containers.
- **Metric separation**: Gaps between key indicators (such as current price vs. stop-loss trigger price) use `space-sm` (8px) within the same grouping, reinforcing semantic proximity.

## Elevation & Depth

This system intentionally rejects diffuse ambient shadows, glowing highlights, and layered skeuomorphism. Financial decision-making requires grounded certainty; interfaces that simulate floating elements add visual noise. Depth is achieved exclusively through flat structural stratification:

1. **Subtle Boundaries Over Drop Shadows**: Cards, containers, and panel shelves use 1px flat borders (`#E9ECEF`) instead of elevation drop shadows. For active or selected states, the border directly transitions to `#0F2744` (or `#E8590C` for stop-loss warnings).
2. **Surface Stratification**:
   - **Level 0 (Base Canvas)**: `#FFFFFF`. The global ground layer.
   - **Level 1 (Structural Shelves / Inactive Cards)**: Flat `#F8F9FA` fill with 1px `#E9ECEF` border.
   - **Level 2 (Active Target / Selected Row)**: `#FFFFFF` fill with high-contrast `#0F2744` 1px border.
   - **Level 3 (Modal / Critical Interruption Overlay)**: Solid white container surrounded by a stark 1px `#212529` frame, placed over an unblurred `#212529` backdrop with 40% uniform opacity.
3. **Zero Diffusion**: No blur effects (`backdrop-filter`) or graduated drop shadows are permitted. Visual weight is determined strictly by tonal contrast and border authority.

## Shapes

The design system uses a controlled, subtle roundedness (`level 1` / `rounded-sm` to `rounded-md`). Sharp corners can feel harsh and unpolished, yet overly rounded or pill-shaped geometries undermine the gravitas of institutional capital management.

- **Micro Components (Badges, Monospaced Code Tags, Tickers)**: 2px border radius (`rounded-xs`). Maintains geometric alignment with monospace numbers.
- **Core Interactive Elements (Buttons, Form Inputs, Segmented Controls)**: 4px border radius (`rounded-sm`). Crisp, stable, and tactile without turning soft.
- **Containers & Data Cards**: 6px border radius (`rounded-md`). Delivers just enough curvature to detach structural units cleanly from the viewport edge while maintaining rigid horizontal lines.
- **Pill/Capsule Prohibition**: Pill-shaped shapes (`border-radius: 9999px`) are strictly prohibited, as they evoke social software tropes and mischaracterize precise numerical limits.

## Components

### Buttons
- **Primary Execution Button**: Deep Navy background (`#0F2744`), text `#FFFFFF`, border-radius `4px`, height `44px`, font weight 600. On hover, shifts to `#1B365D`. Used for confirming calculation rules, saving thresholds, and logging positions.
- **Critical Alert Button**: Attention Orange background (`#E8590C`), text `#FFFFFF`, border-radius `4px`, height `44px`, font weight 600. On hover, shifts to `#D9480F`. Reserved exclusively for immediate stop-loss confirmations and automated sell triggers.
- **Secondary / Ghost Button**: White background, 1px `#E9ECEF` border, text `#212529`. On hover, border changes to `#ADB5BD` and background to `#F8F9FA`.

### Input Fields & Monetary Controls
- Single-line inputs are strictly 40px in height with a 1px `#ADB5BD` border and 4px border radius.
- When focused, border transitions to `#0F2744` with a 0px offset (no glowing outer rings).
- Value entry fields for currency (KRW / 원) and percentages (%) permanently lock unit suffixes to the right edge using `JetBrains Mono` text in `#495057`. Inputs automatically enforce thousands-separator formatting (`1,250,000`).

### Cards & Analytical Modules
- Bounded by a crisp 1px `#E9ECEF` border over `#FFFFFF`.
- Headers are separated by a 1px internal rule line with `space-md` (16px) internal padding.
- **Stop-Loss Breach State**: When a stock breaches its designated threshold, the card frame replaces its gray border with an authoritative 2px `#E8590C` border, accompanied by an ultra-subtle `#FFF4E6` background tint.

### Data Lists & Ticker Rows
- Structured table rows with 48px height, separated by 1px horizontal dividers (`#F1F3F5`).
- Left column: Stock name in `Noto Sans` (weight 600, `#212529`), with 6-digit stock code positioned directly below in `JetBrains Mono` (`#868E96`, 11px).
- Right column: Tabular figures aligning target stop-loss threshold, current trailing variance, and return percentage, right-aligned to maintain vertical decimal tracking.

### Badges & Risk Status Chips
- Height is fixed at 20px, text size is `11px`, border radius is 2px, and padding is `0 6px`.
- **Holding Normal**: Background `#F1F3F5`, text `#495057`, no border.
- **Warning Approaching Stop-Loss (-2% to target)**: Background `#FFF4E6`, border 1px `#F76707`, text `#D9480F`.
- **Target Breached (Immediate Action Required)**: Background `#E8590C`, text `#FFFFFF`, font weight 600.

### Checkboxes & Radio Controls
- Geometric 16x16px boxes with a 1px `#ADB5BD` border and 2px border radius.
- When checked: Solid `#0F2744` fill with a clean white tick mark.
- When unchecked hover: Border darkens to `#495057`.